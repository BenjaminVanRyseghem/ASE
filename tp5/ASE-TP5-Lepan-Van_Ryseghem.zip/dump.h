void dump(
	unsigned char *buffer,
	unsigned int buffer_size,
	int ascii_dump,
	int octal_dump );